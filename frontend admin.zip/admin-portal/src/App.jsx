import { useState } from "react";
import Login from "./components/Login.jsx";
import Sidebar from "./components/Sidebar.jsx";
import Topbar from "./components/Topbar.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import UserMaster from "./pages/UserMaster.jsx";
import DepartmentMaster from "./pages/DepartmentMaster.jsx";
import TicketSearch from "./pages/TicketSearch.jsx";
import NotificationSearch from "./pages/NotificationSearch.jsx";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [user, setUser] = useState(null);

  const [users, setUsers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [notifications, setNotifications] = useState([]);

  function handleLogin() {
    setUser({ name: "Admin", email: "admin@portal.gov" });
    setLoggedIn(true);
  }

  function handleLogout() {
    setLoggedIn(false);
    setUser(null);
    setCurrentPage("dashboard");
  }

  // ── User handlers (replace with API calls) ──
  function addUser(data) {
    const newUser = {
      user_id: users.length + 1,
      ...data,
    };
    setUsers(prev => [...prev, newUser]);
  }

  function updateUser(id, data) {
    setUsers(prev => prev.map(u => u.user_id === id ? { ...u, ...data } : u));
  }

  function deleteUser(id) {
    setUsers(prev => prev.filter(u => u.user_id !== id));
  }

  // ── Department handlers (replace with API calls) ──
  function addDepartment(data) {
    const newDept = {
      department_id: departments.length + 1,
      ...data,
    };
    setDepartments(prev => [...prev, newDept]);
  }

  function updateDepartment(id, data) {
    setDepartments(prev => prev.map(d => d.department_id === id ? { ...d, ...data } : d));
  }

  function deleteDepartment(id) {
    setDepartments(prev => prev.filter(d => d.department_id !== id));
  }

  // ── Dashboard stats (will come from API) ──
  const stats = {
    totalUsers: users.length,
    totalDepartments: departments.length,
    totalTickets: tickets.length,
    openTickets: tickets.filter(t => t.status_name === "Open").length,
    closedTickets: tickets.filter(t => t.status_name === "Closed").length,
    totalNotifications: notifications.length,
  };

  if (!loggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  function renderPage() {
    switch (currentPage) {
      case "dashboard":
        return <Dashboard stats={stats} />;
      case "user-master":
        return (
          <UserMaster
            users={users}
            departments={departments}
            onAdd={addUser}
            onUpdate={updateUser}
            onDelete={deleteUser}
          />
        );
      case "dept-master":
        return (
          <DepartmentMaster
            departments={departments}
            users={users}
            onAdd={addDepartment}
            onUpdate={updateDepartment}
            onDelete={deleteDepartment}
          />
        );
      case "ticket-search":
        return <TicketSearch tickets={tickets} />;
      case "notif-search":
        return <NotificationSearch notifications={notifications} />;
      default:
        return <Dashboard stats={stats} />;
    }
  }

  return (
    <div className="app">
      <Sidebar currentPage={currentPage} onNavigate={setCurrentPage} />
      <div className="main">
        <Topbar currentPage={currentPage} user={user} onLogout={handleLogout} />
        <div className="content">
          {renderPage()}
        </div>
      </div>
    </div>
  );
}
