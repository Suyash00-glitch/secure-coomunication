import { useState } from "react";
import TicketDetail from "../components/TicketDetail.jsx";

export default function TicketSearch({ tickets, onViewDetail, onBack }) {
  const [searchId, setSearchId] = useState("");
  const [result, setResult] = useState(null);
  const [searched, setSearched] = useState(false);

  function handleSearch() {
    const q = searchId.trim();
    if (!q) return;
    const found = tickets.find(t =>
      String(t.ticket_id) === q ||
      `TKT-${String(t.ticket_id).padStart(4, "0")}` === q
    );
    setResult(found || null);
    setSearched(true);
  }

  function handleKeyDown(e) {
    if (e.key === "Enter") handleSearch();
  }

  function handleReset() {
    setSearchId("");
    setResult(null);
    setSearched(false);
  }

  if (result) {
    return <TicketDetail ticket={result} />;
  }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">Ticket Search</div>
          <div className="page-sub">Look up a ticket by its ID</div>
        </div>
      </div>
      <div className="card" style={{ maxWidth: 600 }}>
        <div className="form-full">
          <label className="form-label">Ticket ID</label>
          <input
            className="form-input"
            type="text"
            placeholder="Enter Ticket ID"
            value={searchId}
            onChange={e => setSearchId(e.target.value)}
            onKeyDown={handleKeyDown}
          />
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-primary" onClick={handleSearch}>
            <i className="ti ti-search"></i> Search
          </button>
          {searched && (
            <button className="btn btn-secondary" onClick={handleReset}>
              <i className="ti ti-arrow-back"></i> Back
            </button>
          )}
        </div>
        {searched && !result && (
          <div className="not-found">
            <i className="ti ti-alert-triangle"></i>
            Ticket not found
          </div>
        )}
      </div>
    </div>
  );
}
