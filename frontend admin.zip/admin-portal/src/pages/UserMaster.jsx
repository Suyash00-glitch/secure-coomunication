import { useState } from "react";
import Modal from "../components/Modal.jsx";

export default function UserMaster({ users, onAdd, onUpdate, onDelete, departments }) {
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("all_roles");
  const [deptFilter, setDeptFilter] = useState("all_departments");
  const [statusFilter, setStatusFilter] = useState("all_statuses");
  const [modal, setModal] = useState(null); // null | "add" | { mode: "edit", user } | { mode: "delete", user }

  const filtered = users.filter(u => {
    const q = search.toLowerCase();
    const matchSearch = !q || u.name.toLowerCase().includes(q) || u.email.toLowerCase().includes(q) || String(u.user_id).toLowerCase().includes(q);
    const matchRole = roleFilter === "all_roles" || u.role === roleFilter;
    const matchDept = deptFilter === "all_departments" || u.department === deptFilter;
    const matchStatus = statusFilter === "all_statuses" || u.status === statusFilter;
    return matchSearch && matchRole && matchDept && matchStatus;
  });

  function openAdd() { setModal("add"); }
  function openEdit(user) { setModal({ mode: "edit", user }); }
  function openDelete(user) { setModal({ mode: "delete", user }); }
  function closeModal() { setModal(null); }

  return (
    <div>
      <div className="page-header">
        <div>
          <div className="page-title">User Master</div>
          <div className="page-sub">Manage system users and access roles</div>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>
          <i className="ti ti-plus"></i> Add User
        </button>
      </div>

      <div className="card">
        <div className="search-row">
          <div className="search-wrap">
            <i className="ti ti-search"></i>
            <input
              className="search-input"
              placeholder="Search by name, email, user ID..."
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>
          <select className="filter-select" value={roleFilter} onChange={e => setRoleFilter(e.target.value)}>
            <option value="all_roles">All Roles</option>
            <option value="Admin">Admin</option>
            <option value="External User">External User</option>
            <option value="Internal User">Internal User</option>
          </select>
          <select className="filter-select" value={deptFilter} onChange={e => setDeptFilter(e.target.value)}>
            <option value="all_departments">All Departments</option>
            {departments.map(d => <option value={d.name} key={d.department_id}>{d.name}</option>)}
          </select>
          <select className="filter-select" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="all_statuses">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>

        {filtered.length === 0 ? (
          <div className="empty-state">
            <i className="ti ti-users"></i>
            <p>No users found</p>
            <span className="empty-sub">Try adjusting your search or filters</span>
          </div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>User ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Role</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.user_id}>
                  <td style={{ fontWeight: 600 }}>{u.user_id}</td>
                  <td>{u.name}</td>
                  <td>{u.email}</td>
                  <td>{u.department}</td>
                  <td><span className="badge badge-admin">{u.role}</span></td>
                  <td>
                    <span className={`badge ${u.status === "Active" ? "badge-active" : "badge-inactive"}`}>
                      {u.status}
                    </span>
                  </td>
                  <td>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button className="action-btn" onClick={() => openEdit(u)}><i className="ti ti-edit"></i></button>
                      <button className="action-btn action-btn-danger" onClick={() => openDelete(u)}><i className="ti ti-trash"></i></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modal === "add" && (
        <UserFormModal
          title="Add User"
          departments={departments}
          onClose={closeModal}
          onSubmit={data => { onAdd(data); closeModal(); }}
        />
      )}
      {modal?.mode === "edit" && (
        <UserFormModal
          title="Edit User"
          departments={departments}
          initial={modal.user}
          onClose={closeModal}
          onSubmit={data => { onUpdate(modal.user.user_id, data); closeModal(); }}
        />
      )}
      {modal?.mode === "delete" && (
        <Modal
          title="Delete User"
          onClose={closeModal}
          footer={
            <>
              <button className="btn btn-secondary" onClick={closeModal}>Cancel</button>
              <button className="btn btn-danger" onClick={() => { onDelete(modal.user.user_id); closeModal(); }}>
                <i className="ti ti-trash"></i> Delete
              </button>
            </>
          }
        >
          <p className="confirm-text">
            Are you sure you want to delete user <strong>{modal.user.name}</strong>? This action cannot be undone.
          </p>
        </Modal>
      )}
    </div>
  );
}

function UserFormModal({ title, departments, initial, onClose, onSubmit }) {
  const [name, setName] = useState(initial?.name || "");
  const [email, setEmail] = useState(initial?.email || "");
  const [department, setDepartment] = useState(initial?.department || "");
  const [role, setRole] = useState(initial?.role || "");
  const [status, setStatus] = useState(initial?.status || "Active");

  function handleSubmit(e) {
    e.preventDefault();
    onSubmit({ name, email, department, role, status });
  }

  return (
    <Modal
      title={title}
      onClose={onClose}
      footer={
        <>
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSubmit}>
            <i className="ti ti-check"></i> {initial ? "Update" : "Add"}
          </button>
        </>
      }
    >
      <form onSubmit={handleSubmit}>
        <div className="form-full">
          <label className="form-label">Name <span style={{ color: "#ef4444" }}>*</span></label>
          <input className="form-input" type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Full name" required />
        </div>
        <div className="form-full">
          <label className="form-label">Email <span style={{ color: "#ef4444" }}>*</span></label>
          <input className="form-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="user@dept.gov" required />
        </div>
        <div className="form-row">
          <div>
            <label className="form-label">Department <span style={{ color: "#ef4444" }}>*</span></label>
            <select className="form-select" value={department} onChange={e => setDepartment(e.target.value)} required>
              <option value="">Select Department</option>
              {departments.map(d => <option value={d.name} key={d.department_id}>{d.name}</option>)}
            </select>
          </div>
          <div>
            <label className="form-label">Role <span style={{ color: "#ef4444" }}>*</span></label>
            <select className="form-select" value={role} onChange={e => setRole(e.target.value)} required>
              <option value="">Select Role</option>
              <option value="Admin">Admin</option>
              <option value="External User">External User</option>
              <option value="Internal User">Internal User</option>
            </select>
          </div>
        </div>
        <div className="form-full">
          <label className="form-label">Status</label>
          <select className="form-select" value={status} onChange={e => setStatus(e.target.value)}>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>
      </form>
    </Modal>
  );
}
