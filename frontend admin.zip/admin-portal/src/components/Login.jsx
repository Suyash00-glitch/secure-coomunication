export default function Login({ onLogin }) {
  return (
    <div id="login-screen">
      <div className="login-wrap">
        <div className="login-card">
          <div className="login-logo">
            <div className="login-logo-icon"><i className="ti ti-building-bank"></i></div>
            <h2>Admin Portal</h2>
            <p>Administration Panel</p>
          </div>
          <div className="form-group">
            <label className="form-label">Username</label>
            <input className="form-input" placeholder="Enter username" type="text" />
          </div>
          <div className="form-group">
            <label className="form-label">Password</label>
            <input className="form-input" placeholder="Enter password" type="password" />
          </div>
          <button className="btn btn-primary-full" onClick={onLogin}>
            <i className="ti ti-login"></i> Sign In
          </button>
          <p className="forgot">Forgot password?</p>
        </div>
      </div>
    </div>
  );
}
